<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: #ffffff;
            margin: 0 15px;
            font-weight: bold;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }

        .welcome-text {
            font-family: 'Times New Roman', Times, serif;
            font-size: 30px;
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            margin: 20px;
            background-color: #7070d1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100px;
        }

        .content {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .feature-box {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            width: 250px;
            text-align: center;
            align-items: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 350px;
            margin-bottom: 50px;
        }

        .feature-box img {
            width: 100%;
            height: 60%;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .feature-box h5 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .feature-box p {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 12px;
            margin-bottom: 10px;
        }

        .feature-box button,
        .feature-box a {
            font-size: 12px;
            padding: 5px 10px;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">GALERI FOTO</a>
                <div class="text end">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a href="album" class="btn btn-outline-info" style="margin-right: 10px;">Album</a>
                        </li>
                        <li class="nav-item">
                            <a href="home" class="btn btn-outline-info" style="margin-right: 10px;">Logout</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="welcome-text">
        <p>Selamat Datang di Website Galeri Foto <?php echo e(session('user')->Username); ?></p>
    </div>

    <center>
        <h2>Foto Terbaru</h2>
    </center>

    <div class="content">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="feature-box">
                <img src="<?php echo e(Storage::url($item->LokasiFile)); ?>" alt="Foto 1">
                <h5 class="card-title" style="margin-bottom: 0;"><strong><?php echo e($item->JudulFoto); ?></strong></h5>
                <p class="card-text"><strong><?php echo e($item->DeskripsiFoto); ?></strong></p>
                <p class="card-text"><strong><?php echo e($item->TanggalUnggah); ?></strong></p>
                <form action="/berilike/<?php echo e($item->FotoID); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php
                        $warna = 'black';
                        $userData = session('user');
                        if ($userData && isset($userData->UserID)) {
                            // Periksa apakah session terdefinisi dan properti UserID ada
                            $cek = \App\Models\Like::where('UserID', $userData->UserID)
                                ->where('FotoID', $item->FotoID)
                                ->first();
                            if ($cek) {
                                $warna = 'red';
                            }
                        }
                    ?>

                    <button type="submit" class="btn btn-sm btn-outline-secondary"
                        style="color:<?php echo e($warna); ?>; background-color:#ff9999"><i class="far fa-thumbs-up"></i>
                        Like <?php echo e(\App\Models\Like::where('FotoID', $item->FotoID)->count()); ?></button>
                    <a href="/komentar/<?php echo e($item->FotoID); ?>" class="btn btn-sm btn-outline-secondary"
                        style="background-color:#ff9999;color:black;"><i class="far fa-comment"></i> Komentar </a>
                    <a href="/lihatkomentar/<?php echo e($item->FotoID); ?>" class="btn btn-sm btn-outline-secondary"
                        style=" background-color:#ff9999;color:black;">
                        (<?php echo e(\App\Models\Komentar::where('FotoID', $item->FotoID)->count()); ?>)
                    </a>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\elans\ukk_galerifoto\resources\views/halaman.blade.php ENDPATH**/ ?>