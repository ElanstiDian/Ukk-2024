<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Tambah Foto</title>
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        nav a {
            text-decoration: none;
            color: #ffffff;
            margin: 0 15px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
        <div class="container-fluid">
            <div class="text end">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="album" class="btn btn-outline-info" style="margin-right: 10px;">Kembali</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section>
        <div class="container mt-3 pt-5">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-9 mx-auto">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <form action="/tambahfoto" method="POST" class="form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="judul" class="form-control my-4 py-2" placeholder="Judul Foto" required>
                                <input type="text" name="deskripsi" class="form-control my-4 py-2" placeholder="Deskripsi foto" required>
                                <input type="file" name="file" class="form-control my-4 py-2" placeholder="Foto" required>
                                <select class="form-select" name="album" required>
                                    <option>Pilih....</option>
                                    
                                    <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($items->AlbumID); ?>"><?php echo e($items->NamaAlbum); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <div class="text-center mt-3">   
                                    <input type="submit" value="TAMBAH" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\elans\ukk_galerifoto\resources\views/tambahfoto.blade.php ENDPATH**/ ?>