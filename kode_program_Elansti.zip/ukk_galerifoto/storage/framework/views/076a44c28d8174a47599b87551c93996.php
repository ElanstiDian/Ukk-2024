<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Komentar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .navbar {
            display: flex;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            justify-content: flex-end;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-weight: bold;
            font-family: 'Roboto', sans-serif;
        }

        .comment-form {
            max-width: 500px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0 auto;
        
        }

        .comment-form textarea {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            resize: vertical;
            font-size: 16px;
        }

        .comment-form button {
            width: 100px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 15px 0;
            cursor: pointer;
            font-size: 16px;
        }

        .comment-form button:hover {
            background-color: #0056b3;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
        <div class="container-fluid">
            <div class="text end">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="javascript:history.go(-1);" class="btn btn-outline-info"
                            style="margin-right: 10px;">Kembali</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <br>
    <br>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment-container mx-auto">
                        <form action="/komentar/<?php echo e($ft->FotoID); ?>" method="post" class="comment-form">
                            <?php echo csrf_field(); ?>
                            <textarea name="IsiKomentar" placeholder="Tambahkan Komentar" rows="5"></textarea>
                            <button type="submit" class="submit-button">Kirim</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\elans\ukk_galerifoto\resources\views/komentar.blade.php ENDPATH**/ ?>