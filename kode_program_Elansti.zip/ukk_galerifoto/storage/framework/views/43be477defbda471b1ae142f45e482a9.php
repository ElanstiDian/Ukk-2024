<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-weight: bold;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }

        .foto {
            margin-right: 20px;
            /* Atur jarak kanan antara foto-foto */
            margin-left: 20px;
            /* Atur jarak kiri antara foto-foto */
            width: 200px;
            height: 250px;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
        <div class="container-fluid">
            <div class="text end">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="javascript:history.go(-1);" class="btn btn-outline-info"
                            style="margin-right: 10px;">Kembali</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <br>
    <div class="container">
        <main class="grid">
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" class="foto" width="100%" height="auto">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\Users\elans\ukk_galerifoto\resources\views/lihatalbum.blade.php ENDPATH**/ ?>