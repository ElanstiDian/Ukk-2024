<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Userr;

class FotoController extends Controller
{
    public function unggah()
    {
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('tambahfoto', compact('album'));
    }

    public function unggahfoto(Request $request)
    {
        if ($request->hasFile('file')) {
            $locate = $request->file('file')->store('public/image');
            $data = new Foto();
            $data->JudulFoto = $request->input('judul');
            $data->DeskripsiFoto = $request->input('deskripsi');
            $data->TanggalUnggah = date('Y-m-d H:i:s');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->input('album');
            $data->UserID = session('user')->UserID;
            $data->save();
            return redirect('/halaman');
        }
    }

    public function halaman()
    {
        $foto = Foto::all();
        return view('halaman', compact('foto'));
    }

    public function viewalbum($AlbumID)
    {
        $album = Album::find($AlbumID);
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('lihatalbum', compact('album', 'foto'));
    }
}
