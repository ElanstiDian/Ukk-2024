<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;

class RegisterController extends Controller
{
    public function tampil()
    {
        return view('register');
    }
    public function aksidaftar(Request $request)
    {
        $data = new Userr();
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->NamaLengkap = $request->input('NamaLengkap');
        $data->Alamat = $request->input('Alamat');
        $data->save();

        return redirect('/login');

    }
}
