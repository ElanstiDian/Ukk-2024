<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;

class LoginController extends Controller
{
    public function tampillog()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $data = Userr::where('Username', $request->input('username'))
                     ->where('password', $request->input('password'))
                     ->first();

        if ($data === null) {
            return redirect('/login')->with('pesan', 'Username / Password Salah !');
        } else {
            session()->put('user', $data);
            return redirect('/halaman');
        }
    }

    public function logout()
    {
        session()->flush();
        return redirect('/home');
    }
}
