<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Komentar;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Like;

class LikeController extends Controller
{
    
    public function like($FotoID)
    {
        $cek = Like::where('UserID', session('user')->UserID)
                   ->where('FotoID', $FotoID)
                   ->first();
        if(!$cek) {
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = date('Y-m-d');
            $data->save();

            return redirect()->back();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }
}
