<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Album;
use App\Models\Foto;

class AlbumController extends Controller
{
    public function tampil()
    {
        $album = Album::all(); // Mengambil semua data album dari database
        return view('tambahalbum', compact('album'));
    
    }

    public function tambahalbum(Request $request)
    {
        // Periksa apakah pengguna sudah masuk sebelum mengakses properti 'UserID'
        if (session('user') !== null) {
            $data = new Album();
            $data->namaalbum = $request->input('NamaAlbum');
            $data->deskripsi = $request->input('Deskripsi');
            $data->tanggaldibuat = $request->input('TanggalDibuat');
            $data->UserID = session('user')->UserID;
            $data->save();

            return redirect('/album');
        } else {
            // Tangani kasus ketika pengguna belum masuk
            return redirect('/login');
        }
    }
}
