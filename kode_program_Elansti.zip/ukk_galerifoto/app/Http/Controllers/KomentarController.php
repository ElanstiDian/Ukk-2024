<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Userr;
use App\Models\Komentar;
use App\Models\Foto;

class KomentarController extends Controller
{
    public function tampilkomentar($FotoID)
    {
        if (session('user') != null) {
            $komentar = Komentar::all();
            $foto = Foto::where('FotoID', $FotoID)->get();
            return view('komentar', compact('komentar', 'foto', 'FotoID'));
        } else {
            return redirect('/login');
        }
    }

    public function lihatkomentar($FotoID)
    {
        if (session('user') != null) {   
            $komentar = Komentar::where('FotoID', $FotoID)->get();
            $user = Userr::all();
            return view('lihatkomentar', compact('komentar', 'user', 'FotoID'));
        } else {
            return redirect('/login');
        }
    }

    public function tambahkomentar(Request $request, $FotoID)
    {
            $request->validate([
                'IsiKomentar' => 'required', 
            ]);
        
            // Inisialisasi objek Komentar baru
            $data = new Komentar();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->IsiKomentar = $request->input('IsiKomentar');
            $data->TanggalKomentar = date('Y-m-d');
            $data->save();
            
            return redirect('/halaman');
        }
        
    }
    
   


