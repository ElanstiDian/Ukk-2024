<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Lihat Komentar</title>
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: #ffffff;
            margin: 0 15px;
            font-weight: bold;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }

        .comment-container textarea {
            width: 50%;
            height: 50px;
            padding: 10px;
            border-radius: 15px;
            border: 1px solid #cccccc;
            resize: none;
        }

        .comment-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .comment-form {
            width: 300px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px #0000001a;
        }

        .comment-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .comment-form textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 8px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            resize: vertical;
        }
        /* Menambahkan gaya untuk variabel $nama */
        .comment-container span.nama {
            font-weight: bold;
            color: #000000;
            font-family: 'Times New Roman', sans-serif;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
            <div class="container-fluid">
                <div class="text end">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a href="javascript:history.go(-1);" class="btn btn-outline-info"
                                style="margin-right: 10px;">Kembali</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
        <div class="content">
            <div class="comment-container">
                <form class="comment-form">
                    <label for="comment">Isi Komentar:</label>
                    @foreach ($komentar as $item)
                        @if ($item->FotoID == $FotoID)
                            @php
                                $nama = $user->where('UserID', $item->UserID)->first();
                            @endphp
                            @if ($nama)
                                <span class="nama">&#64;{{ $nama->Username }}</span>
                                <textarea>{{ $item->IsiKomentar }}</textarea>
                            @endif
                        @endif
                    @endforeach
                </form>
            </div>
        </div>

        </div>
  
</body>

</html>
