<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Login</title>
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: #ffffff;
            margin: 0 15px;
            font-weight: bold;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }

        .error-message {
            color: #ff0000;
            font-size: 14px;
            text-align: center;
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">GALERI FOTO</a>
            <div class="text end">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="home" class="btn btn-outline-info" style="margin-right: 10px;">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section>
        <center>
            <div class="container mt-5 pt-5">
                <div class="row">
                    <div class="col-12 col-sm-8 col-md-6 m-auto">
                        <div class="card border-0 shadow">
                            <div class="card-body">
                                <svg class="mx-auto my-3" xmlns="http://www.w3.org/2000/svg" width="50"
                                    height="50" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                    <path fill-rule="evenodd"
                                        d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg>

                                <div class="error-message">{!! session('pesan') !!}</div>

                                <form action="/login" method="post">
                                    @csrf
                                    <input type="text" name="username" id="" class="form-control my-4 py-2" placeholder="Username" />
                                    <input type="password" name="password" id="" class="form-control my-4 py-2" placeholder="Password" />
                                    <div class="text end">
                                        <ul class="navbar-nav ml-auto">
                                            <li class="nav-item">
                                                <button ="halaman" class="btn btn-outline-info" style="margin-right: 10px;">Login</a>
                                            </li>
                                        </ul>
                                        <br>
                                        <a href="register" class="link-primary">Belum punya akun? Daftar Disini!</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </center>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
    
</body>

</html>
