<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Album</title>
    <style>
        body {
            background: linear-gradient(to top left, #33ccff 0%, #ff9999 100%);
            background-blend-mode: multiply;
            background-position: center;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        nav a {
            text-decoration: none;
            color: white;
            margin: 0 15px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            text-align: center;
        }

        .feature-box {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px #0000001a;
            padding: 20px;
            margin-top: 30px;
            margin-right: 20px;
            text-align: center;
            box-sizing: border-box;
            width: 300px;
            height: 400px;
        }

        .feature-box img {
            width: 100%;
            max-width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .feature-box .btn-primary {
            margin-top: -10px;
        }
    </style>
</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary rounded shadow">
            <div class="container-fluid">
                <a class="navbar-brand" href="halaman">GALERI FOTO</a>

                <div class="text end">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a href="tambahfoto" class="btn btn-outline-info" style="margin-right: 10px;">Tambah
                                Foto</a>
                        </li>
                        <li class="nav-item">
                            <a href="tambahalbum" class="btn btn-outline-info" style="margin-right: 10px;">Tambah
                                Album</a>
                        </li>
                        <li class="nav-item">
                            <a href="home" class="btn btn-outline-info" style="margin-right: 10px;">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="row">
                @foreach ($album as $data)
                    <div class="col-md-4">
                        <div class="feature-box">
                            <img src="{{ asset('asset/image/album.png') }}" class="brand_logo" alt="Logo">
                            <div class="card-body">
                                <p class="card-text" style="font-family:'times new roman'">{{ $data->NamaAlbum }}</p>
                                <p class="card-text" style="font-family:'times new roman'">{{ $data->Deskripsi }}</p>
                                
                                <div class="text-center mt-2">
                                    <a href="/lihatalbum/{{ $data->AlbumID }}" class="btn btn-primary">Lihat Album</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

    </header>

</body>

</html>
