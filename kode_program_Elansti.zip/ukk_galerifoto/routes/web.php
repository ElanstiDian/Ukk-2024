<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AlbumController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\KomentarController;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komentar;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/home', function () {
    return view('home');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/register', [RegisterController::class,'tampil']);
Route::post('/register', [RegisterController::class,'aksidaftar']);


Route::get('/register', function () {
    return view('register');
});

Route::get('/album', function () {
    return view('album');
});

Route::get('/login', [LoginController::class, 'tampillog']);
Route::post('/login', [LoginController::class, 'login']);


Route::get('Home', [LoginController::class, 'Login']);
Route::get('logout', [LoginController::class, 'logout']);

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});

Route::get('/album', function () {
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('album', compact('album'));
});

Route::post('/album', [AlbumController::class, 'tambahalbum']);

Route::get('/tambahfoto', function () {
    return view('tambahfoto');
});

Route::get('/halaman',[FotoController::class,'halaman']);

Route::get('/tambahfoto',[FotoController::class,'unggah']);
Route::post('/tambahfoto',[FotoController::class,'unggahfoto']);
Route::get('/lihatalbum/{FotoID}', [FotoController::class,'viewalbum']);


Route::get('/komentar/{FotoID}', [KomentarController::class, 'tampilkomentar']);
Route::post('/komentar/{FotoID}', [KomentarController::class, 'tambahkomentar']);
Route::get('/lihatkomentar/{FotoID}', [KomentarController::class ,'lihatkomentar']);
Route::post('/komentar/{FotoID}', [KomentarController::class, 'tambahkomentar']);


Route::get('/halaman/{FotoID', [LikeController::class, 'lihatfoto']);
Route::post('/berilike/{FotoID}', [LikeController::class, 'like']);

